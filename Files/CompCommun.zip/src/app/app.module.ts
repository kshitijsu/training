import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { BindingDemoComponent } from './binding-demo/binding-demo.component';
import { BasicComponent } from './basic/basic.component';
import { NumUpDownComponent } from './num-up-down/num-up-down.component';

@NgModule({
  declarations: [
    AppComponent,
    BindingDemoComponent,
    BasicComponent,
    NumUpDownComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
