﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Aug272020_Itron_AdoNet.Models;
using System.Data.Entity.Core.Objects;

namespace Aug272020_Itron_AdoNet
{
    class ADONetEFDemo
    {
        static void Main(string[] args)
        {

            Models.EmployeeDbEntities db = new Models.EmployeeDbEntities();



            int Option = 0;
            do
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("1.Display Employee Details\n2.Add New Employee\n3.Edit Employee\n4.Delete Employee\n5.Call Get Emp Name By ID Stored Proc\n6.Call Get Emp details Stored Proc\n10.Exit");
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.Write("Enter option:");
                Option = int.Parse(Console.ReadLine());

                if (Option == 1)
                {
                    DisplayEmployeeDetails(db);
                }

                if (Option == 2)
                {
                    AddNewEmployee(db);
                }


                if (Option == 3)
                {
                    UpdateEmployee(db);
                }

                if (Option == 4)
                {
                    DeleteEmployee(db);
                }

                if (Option == 5)
                {
                    Call_SP_GetEmployeeNameByID(db);
                }

                if (Option == 6)
                {
                    Call_SP_GetEmployees(db);
                }

            } while (Option != 10);




        }

        private static void Call_SP_GetEmployees(EmployeeDbEntities db)
        {
            Console.WriteLine("Result :");
            foreach (var objEmp in db.GetEmployees())
            {
                Console.WriteLine($"EmpName : {objEmp.EmpName} . Address :{objEmp.Address}, Salary :{objEmp.Salary} \n Enter new values  \n");

            }
            Console.WriteLine("Press Any key for Menu....");

            Console.ReadKey();

        }

        private static void Call_SP_GetEmployeeNameByID(EmployeeDbEntities db)
        {
            Console.Clear();
            Console.Write("Enter Emp Id :"); string Empid = Console.ReadLine();

            ObjectParameter prm = new ObjectParameter("EmployeeName", "");
            db.GetEmployeeNameByID(int.Parse(Empid), prm);


            Console.WriteLine( "Emp Name for Emp Id:"+ Empid + "is " + prm.Value);
            Console.WriteLine("Press Any key for Menu....");

            Console.ReadKey();
        }

        private static void DeleteEmployee(EmployeeDbEntities db)
        {
            Employee objEmp = new Employee();

           // var st = db.Entry(objEmp).State;


            Console.Clear();

            Console.Write("Enter Emp Name to Edit: ");
            string _EmpName = Console.ReadLine();


            objEmp = db.Employees.FirstOrDefault(e => e.EmpName.Contains(_EmpName));

            if (objEmp == null)
            {
                Console.WriteLine("Record Not found...");
                return;

            }

            Console.WriteLine($"EmpName : {objEmp.EmpName} . Address :{objEmp.Address}, Salary :{objEmp.Salary} \n Enter new values  \n");

            Console.Write("Confirm Delete Y/N :");
            
            string st = Console.ReadLine();

            if (st.ToUpper()=="Y")
            {

                db.Employees.Remove(objEmp);
                db.SaveChanges();
                Console.WriteLine("Record Deleted \nPress Any key for Menu....");
            }
            else

            Console.WriteLine("Press Any key for Menu....");

            Console.ReadKey();
        }

        private static void UpdateEmployee(EmployeeDbEntities db)
        {
            Employee objEmp = new Employee();

            var st = db.Entry(objEmp).State;


            Console.Clear();

            Console.Write("Enter Emp Name to Edit: ");
            string _EmpName = Console.ReadLine();


         objEmp=   db.Employees.FirstOrDefault(e => e.EmpName.Contains(_EmpName));

            if (objEmp==null)
            {
                Console.WriteLine("Record Not found...");
                return;

            }

            Console.WriteLine($"EmpName : {objEmp.EmpName} . Address :{objEmp.Address}, Salary :{objEmp.Salary} \n Enter new values  \n");

            Console.Write("Enter Emp Name: ");
            objEmp.EmpName = Console.ReadLine();

            Console.Write("Address: ");
            objEmp.Address = Console.ReadLine();
            Console.Write("Salary: ");
            objEmp.Salary = decimal.Parse(Console.ReadLine());

            db.SaveChanges();

            Console.WriteLine("Updated \nPress Any key for Menu....");
            Console.ReadKey();

        }

        private static void AddNewEmployee(EmployeeDbEntities db)
        {
            Models.Employee obj = new Employee();


            Console.Clear();

            Console.Write("Enter Emp Name: ");
            obj.EmpName = Console.ReadLine();

            Console.Write("Address: ");
            obj.Address = Console.ReadLine();
            Console.Write("Salary: ");
            obj.Salary = decimal.Parse(Console.ReadLine());

            db.Employees.Add(obj);
                db.SaveChanges();
            Console.WriteLine("Press Any key for Menu....");
            Console.ReadKey();


        }

        private static void DisplayEmployeeDetails(EmployeeDbEntities db)
        {
            Console.Clear();

            foreach (Models.Employee emp in db.Employees.ToList())
            {

Console.WriteLine($"EmpName : {emp.EmpName} . Address :{emp.Address}, Salary :{emp.Salary}   ");
            }
               
             Console.WriteLine("Press Any key for Menu....");
            Console.ReadKey();

        }
    }
}
