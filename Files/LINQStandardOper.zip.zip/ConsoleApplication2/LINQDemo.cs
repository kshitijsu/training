﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class LINQDemo
    {
        static void Main()
        {
            // LINQSyntax.BasicIntro();
            //   LINQSyntax.WhereOper();
            //  LINQSyntax.SelectOper();
            //LINQSyntax.OrderByOper();
            //LINQSyntax.GroupByOper();
            LINQSyntax.JoinOper();
        }
    }


    class LINQSyntax
    {
        static Models.Customer[] customers;
        static Models.Product[] products;

        static LINQSyntax()
        {
			customers = new Models.Customer[] {
             new Models.Customer {Name = "Paolo", City = "Brescia",
	  Country = Models.Countries.Italy, Orders =
  new Models.Order[] {
	new Models.Order {Quantity = 3, IdProduct = 1 , Shipped = false, Month = "January"},
	new Models.Order {Quantity = 5, IdProduct = 2 , Shipped = true, Month = "May"}
  }},

	new Models.Customer {Name = "Marco", City = "Torino", Country = Models.Countries.Italy, Orders =
  new Models.Order[] {
	new Models.Order {Quantity = 10, IdProduct = 1 , Shipped = false, Month = "July"},
	new Models.Order {Quantity = 20, IdProduct = 3 , Shipped = true, Month = "December"}}},

	new Models.Customer {Name = "James", City = "Dallas", Country = Models.Countries.USA, Orders =
  new Models.Order[] {
	new Models.Order {Quantity = 20, IdProduct = 3 , Shipped = true, Month = "December"}}},

	   new Models.Customer {Name = "Bond", City = "Dallas", Country = Models.Countries.USA, Orders =
  new Models.Order[] {
	new Models.Order {Quantity = 20, IdProduct = 3 , Shipped = true, Month = "January"}}},

	new Models.Customer {Name = "Frank", City = "Seattle", Country = Models.Countries.USA, Orders =
  new Models.Order[] {
	new Models.Order {Quantity = 20, IdProduct = 5 , Shipped = false, Month = "July"}}},

	 new Models.Customer {Name = "Smith", City = "Seattle", Country = Models.Countries.USA, Orders =
  new Models.Order[] {
	new Models.Order {Quantity = 20, IdProduct = 5 , Shipped = false, Month = "July"}}}



 };

            products = new Models.Product[] {
    new Models.Product {IdProduct = 1, Price = 10 },
    new Models.Product {IdProduct = 2, Price = 20 },
    new Models.Product {IdProduct = 3, Price = 30 },
    new Models.Product {IdProduct = 4, Price = 40 },
    new Models.Product {IdProduct = 5, Price = 50 },
    new Models.Product {IdProduct = 6, Price = 60 }};




        }

        static List<Employee> lst = new List<Employee> { new Employee { EmpId=100, EmpName="Ganesh", Address="Blr" },
            new Employee { EmpId=101, EmpName="ramesh", Address="Blr" },
            new Employee { EmpId=102, EmpName="suresh", Address="pun" },
            new Employee { EmpId=103, EmpName="nagesh", Address="mum" },
            new Employee { EmpId=104, EmpName="rajesh", Address="dhl" },


        };
        public static void BasicIntro()
        {
            // Method call Expression
            IEnumerable<Employee> qry = lst.Where(e => e.Address == "Blr");

            foreach (var item in qry)
            {
                Console.WriteLine(item.EmpName + "from " + item.Address);
            }

            var rst = lst.Where(emp => emp.EmpId > 100).ToList();



        }

        public static void WhereOper()
        {
            // method call style

            var qry = customers.Where(c => c.Country == Models.Countries.Italy)
          .Select(c => new { c.Name, c.City });

            // query expression style 
            var WhereExpr =
            from c in customers
            where c.Country == Models.Countries.Italy
            select new { c.Name, c.City };

        }


        public static  void SelectOper()
        {
            var qry1 = customers.Select(c => c.Name);

            
            var qry2 = customers.Select(c => new Models.Customer {
                Name = c.Name, Country = c.Country });
var rst = qry2.ToList();

            var qry3 = customers.Select(c => new { CustName = c.Name, Country = c.City });
            




            var qry4 = customers.Select(c => c.Orders);



            var qry5 = customers.SelectMany(c => c.Orders);


            var orders =
                customers
    .Where(c => c.Country == Models.Countries.Italy)
    .SelectMany(c => c.Orders);
            var orders2 =
                customers
    .Where(c => c.Country == Models.Countries.Italy)
    .Select(c => c.Orders);

            foreach (var item in orders) { Console.WriteLine(item); }




            IEnumerable< Models.Order> orders1 =
     from c in customers
         // where c.Country == Countries.Italy
     from o in c.Orders
     select o;





        }

        public static  void OrderByOper()
        {
            var expr =
    from c in customers
    where c.Country == Models.Countries.Italy
    orderby c.Name descending, c.Country
    select new { c.Name, c.City };



            var expr1 = customers
    .Where(c => c.Country == Models.Countries.Italy)
    .OrderByDescending(c => c.Name)
    .ThenBy(c => c.Country);
            //.Select(c=>c);


            

        }



        public static  void GroupByOper()
        {
            

            var expr =
    customers
    .GroupBy(c => new { c.Country }, c => new { c.Name, c.City, c.Country, c.Orders });

            foreach (var customerGroup in expr)
            {
                Console.WriteLine("Country: {0}", customerGroup.Key);
                Console.WriteLine(customerGroup.Key + " has - >  " + customerGroup.Count());
                foreach (var item in customerGroup)
                {
                    Console.WriteLine("  {0}", item.Name);
                }
            }

            var results = from c in customers
                          group c by c.Country into g
                          select new { Country = g.Key, groupedResult = g.ToList() };


            var results1 = from c in customers
                           from o in c.Orders
                           group o by o.Month into g
                           // orderby g.Key 
                           select new { Month = g.Key, Orders = g.ToList() };

        }

        public static  void JoinOper()
        {

            var expr1 =
customers
.SelectMany(c => c.Orders);

            var expr2 =
customers
.Select(c => c.Orders);


            var expr =
    customers
    .SelectMany(c => c.Orders)

     .Join(products,
           o => o.IdProduct,
           p => p.IdProduct,
           (o, p) => new { o.Month, o.Shipped, p.IdProduct, p.Price });

            var src = expr.ToList();

          



            //var res = from c in customers
            //          from o in c.Orders
            //          join p in products on o.IdProduct equals p.IdProduct into g
            //          from d in g.DefaultIfEmpty()
            //          select new
            //          {
            //              o.Month,
            //              o.Shipped,
            //              price = (d == null) ? -100 : d.Price

            //          };

            //var res = from c in customers
            //          from o in c.Orders
            //          join p in products on o.IdProduct equals p.IdProduct into g
            //          from d in g.DefaultIfEmpty()
            //          select new
            //          {
            //              o.Month,
            //              o.Shipped,
            //              product = d

            //          };


            //foreach (var item in expr )
            //{
            //    Console.WriteLine(item);
            //}


          
        }


    }

}
