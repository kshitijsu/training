﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{

    delegate int dlgDemo(int a, int b);


    class DelegateDemo
    {

        static void Main()
        {
            //dlgDemo fptr = new dlgDemo(Maths.Add); // 1.0 syntax
            dlgDemo fptr = Maths.Add; // 2.0 syntax

            fptr += Maths.Multi;
            fptr += Maths.Add;
            //fptr -= Maths.Add;

            fptr += delegate (int a, int c) // Anonymous Block/Method
             { return a + c; };


            fptr +=  (int a, int c) => { return a + c; };  //Lambda Expression
            fptr += ( a,  c) => { return a + c; };  //Lambda Expression- Implicitly Typed Args
            fptr += (a, c) =>  a + c;   //Lambda Expression- Expression Body

            //public delegate void Action<in T>(T obj);
            // 3.0 generic Delegate 16 overloads
            Action<int> fptr2 = i => { };
            Func<int, int, int> fptr3 = (a, b) => a + b;

            

            Console.WriteLine(fptr(100,200));  

        }



    }

    class Maths
    {
       public  static int Add(int x, int y)
        { return x + y; }

        public static int Multi(int x, int y)
        { return x * y; }

    }
}
