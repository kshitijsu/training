import { Component, OnInit ,DoCheck 
  ,AfterContentInit  
  ,AfterContentChecked  
  ,AfterViewInit  
  ,AfterViewChecked  
  ,OnDestroy } from '@angular/core';

@Component({
  selector: 'app-life-cycle',
  templateUrl: './life-cycle.component.html',
  styleUrls: ['./life-cycle.component.css']
})
export class LifeCycleComponent implements OnInit ,DoCheck 
,AfterContentInit  
,AfterContentChecked  
,AfterViewInit  
,AfterViewChecked  
,OnDestroy   {

name: string ='';  

constructor() {  
console.log('Constructor Called');  
}  

ngOnInit() {  
console.log('ngOnInit Called');  
}  

ngOnChanges(){  
console.log('ngOnChanges Called');  
}  

ngDoCheck(){  
console.log('ngOnDoCheck Called');  
}  

ngAfterContentInit(){  
console.log('ngAfterContentInit Called');  
}  

ngAfterContentChecked(){  
console.log('ngAfterContentChecked Called');  
}  

ngAfterViewInit(){  
console.log('ngAfterViewInit Called');  
}  

ngAfterViewChecked(){  
console.log('ngAfterViewChecked Called');  
}  

ngOnDestroy(){  
console.log('ngOnDestroy Called');  
}  

}
