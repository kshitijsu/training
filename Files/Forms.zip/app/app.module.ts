import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { BindingDemoComponent } from './binding-demo/binding-demo.component';
import { BasicComponent } from './basic/basic.component';
import { NumUpDownComponent } from './num-up-down/num-up-down.component';
import {FormsModule ,ReactiveFormsModule } from "@angular/forms";
import { StructDirectiveComponent } from './struct-directive/struct-directive.component';
import { EmpDataProviderService  } from "./data-provider.service";
import { TmpledFormComponent } from './tmpled-form/tmpled-form.component';
import { ReactiveFormComponent } from './reactive-form/reactive-form.component';
@NgModule({
  declarations: [
    AppComponent,
    BindingDemoComponent,
    BasicComponent,
    NumUpDownComponent,
    StructDirectiveComponent,
    TmpledFormComponent,
    ReactiveFormComponent
  ],
  imports: [
    BrowserModule,FormsModule,ReactiveFormsModule
  ],
  providers: [EmpDataProviderService],
  bootstrap: [AppComponent]
})
export class AppModule { }
