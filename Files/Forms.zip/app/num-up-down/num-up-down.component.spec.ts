import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NumUpDownComponent } from './num-up-down.component';

describe('NumUpDownComponent', () => {
  let component: NumUpDownComponent;
  let fixture: ComponentFixture<NumUpDownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NumUpDownComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NumUpDownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
