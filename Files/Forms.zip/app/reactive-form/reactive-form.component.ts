import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css']
})
export class ReactiveFormComponent implements OnInit {

  

 
    rForm:FormGroup;
    post:any;
    Comment:string="";
    FullName:string="";
  fullNameValidMsg='this field is required';
  
  
    constructor(private fb:FormBuilder){
  
  this.rForm=fb.group(
    {
      'FullName':[null,Validators.required],
      'Comment':[null,Validators.compose(
        [Validators.required,Validators.minLength(30),Validators.maxLength(250)]
          )],
          'validate':''
    }
  )
  
  
    }
  
  handlePost(post){
  this.Comment=post.Comment;
  this.FullName=post.FullName;
  
  }
  
  
      ngOnInit()
   {
  
        this.rForm.get('validate').valueChanges.subscribe
        (
  
            (validate)=>
                {
  
                    if (validate=='1') 
                    {
                        this.rForm.get('FullName').setValidators([Validators.required, Validators.minLength(3)]);
                        this.fullNameValidMsg="min 3 char";
  
                    }
                    else  
                    {
                          this.rForm.get('FullName').setValidators([Validators.required]); 
                          this.fullNameValidMsg="this field is required";
                    }
  
                    this.rForm.get('FullName').updateValueAndValidity();
        
  
                }
        )
      }
  
  
  }
  