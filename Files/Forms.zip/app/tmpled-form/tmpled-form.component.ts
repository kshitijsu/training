import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-tmpled-form',
  templateUrl: './tmpled-form.component.html',
  styleUrls: ['./tmpled-form.component.css']
})
export class TmpledFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  onSubmit(form: NgForm)
  {

      alert(form.value.FullName  + '   ' + form.value.comment  )

  }
  
track(arg)
{
  console.log(arg);
  
}
}
