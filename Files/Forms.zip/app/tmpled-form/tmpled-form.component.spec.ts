import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TmpledFormComponent } from './tmpled-form.component';

describe('TmpledFormComponent', () => {
  let component: TmpledFormComponent;
  let fixture: ComponentFixture<TmpledFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TmpledFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TmpledFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
