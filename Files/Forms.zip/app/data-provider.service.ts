import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmpDataProviderService {

  constructor() { }

  getEmployeeDetails()
  {
    
    var  emps= 
     [{EmpName:'Ganesh', EmpID:1000, Status:'Active',isQuit:false},
  {EmpName:'Mahesh', EmpID:1001, Status:'OnLeave',isQuit:true},
  {EmpName:'Dinesh', EmpID:1002, Status:'NewJoin',isQuit:false},
  {EmpName:'Suresh', EmpID:1003, Status:'OnBench',isQuit:true},
  {EmpName:'Ramesh', EmpID:1004, Status:'Active',isQuit:false},
  ];

  return emps;
  
  }
}
