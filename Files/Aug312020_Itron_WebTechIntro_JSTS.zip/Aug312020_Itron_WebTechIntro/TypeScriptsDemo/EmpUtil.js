"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmployeeUtility = void 0;
var EmployeeUtility = /** @class */ (function () {
    function EmployeeUtility() {
    }
    EmployeeUtility.prototype.GenerateEmpID = function () {
        return 1000;
    };
    return EmployeeUtility;
}());
exports.EmployeeUtility = EmployeeUtility;
//# sourceMappingURL=EmpUtil.js.map