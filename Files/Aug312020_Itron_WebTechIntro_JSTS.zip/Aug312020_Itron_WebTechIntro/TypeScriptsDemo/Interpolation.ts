﻿// Template Strings (strings that use backticks)
// String Interpolation with Template Strings
let EmpName = 'Ganesh';
let greeting = `Hi ${EmpName}, how are you?`
// Multiline Strings with Template Strings
let multiline = `This is an example






of a multiline string`;


let tmp = `


`;

console.log(EmpName);
console.log(greeting);
console.log(multiline);