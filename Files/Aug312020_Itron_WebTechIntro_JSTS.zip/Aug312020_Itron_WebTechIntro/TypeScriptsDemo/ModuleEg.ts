﻿import { EmployeeUtility } from './EmpUtil'


let objEU = new EmployeeUtility();

console.log(objEU.GenerateEmpID());
