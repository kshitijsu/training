﻿export class EmployeeUtility {
    public GenerateEmpID(): number {
        return 1000;
    }
}