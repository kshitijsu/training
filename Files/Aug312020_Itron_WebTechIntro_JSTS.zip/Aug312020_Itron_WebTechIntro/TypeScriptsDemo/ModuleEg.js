"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var EmpUtil_1 = require("./EmpUtil");
var objEU = new EmpUtil_1.EmployeeUtility();
console.log(objEU.GenerateEmpID());
//# sourceMappingURL=ModuleEg.js.map