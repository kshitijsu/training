﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace aug242020_itron_day1
{
    class Program
    {
        static void Main(string[] args)
        {
            clsA objA = new clsA();
            //objA.var_pub = 134;

            objA.Display();
            clsC objC = new clsC();
            objC.Display();


            Console.ReadKey();

        }
    }

    //abstract   class clsA
    //  {
    //      //int var_Defa = 100;
    //      //private int var_prv=100;
    //      //public int var_pub = 100;
    //      //protected int var_ptd = 100;

    //      public abstract void Display();
    //      //{
    //      //    Console.WriteLine("In Display of cls A");
    //      //}


    //  }

     class clsA
    {
        

        public virtual void Display()
        {
            Console.WriteLine("In Display of cls A");
        }


}



    class clsB :clsA
    {

        public override void Display()
        {
           // base.Display();
            Console.WriteLine("In Display of cls B");


        }

        //public override void Display()
        //{
        //    Console.WriteLine("In Display of cls B");
        //}

    }



    class clsC:clsB
    {

        public override void Display()
        {
            Console.WriteLine("In Display of cls C");
        }
    }
}
