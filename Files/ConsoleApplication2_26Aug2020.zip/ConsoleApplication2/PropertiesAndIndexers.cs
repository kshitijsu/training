﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class PropertiesAndIndexers
    {
        static void Main()
        {
            Student std = new ConsoleApplication2.Student();
       
            std.StudentId = 1237;
            std.StudentId = 123;
            std.DOB = DateTime.Parse("12-12-2012");
            Console.WriteLine(std.StudentId);
            Console.WriteLine(std.Age);


            std[0] = 5555555;
            Console.WriteLine(std[0]);



        }
    }

    class Student
    {
        // full syntax 1.0

        int[] PhoneNos = {123456,2132343,4565565,65767 };

        private int _StudentId;

        public int StudentId
        {
            get { return _StudentId; }
            set { 
                if (value>=1000)
                    {
                        _StudentId = value;
                    }
                }
        }

        // 3.0 Auto Properties

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public DateTime DOB { get; set; }

        public int Age { get { return DateTime.Now.Year-  this.DOB.Year;  } }

        public int this[int index]
        {
            get { return this.PhoneNos[index];  }
            set { this.PhoneNos[index] = value; }
        }


        public int this[int index,int std]
        {
            get { return  this.PhoneNos[index]; }
            set { this.PhoneNos[index] = std + value; }
        }
    }



}
