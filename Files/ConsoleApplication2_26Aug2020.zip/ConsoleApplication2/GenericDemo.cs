﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class GenericDemo
    {

        static void Main()
        {
            IComparable i = 120;

            IComparable d = 123.433;

            IComparable st = "";


            Min(100, 200);

            Min("string", 200);


           // Min<int>(100, "");
        }


     static    IComparable Min(IComparable a, IComparable b)
        {
            if (a.CompareTo(b) < 0)
                return a;
            else
                return b;

        }

        static string Min<T>(T a, T b) where T:IComparable<T>
        {
            if (a.CompareTo(b) < 0)
                return "Lesser";
            else
                return "Greater";
        }


    }
}
