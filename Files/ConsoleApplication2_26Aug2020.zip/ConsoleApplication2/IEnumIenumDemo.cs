﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ConsoleApplication2
{
    class IEnumIenumDemo
    {

        static void Main()
        {
            Countries objc = new Countries();


            foreach (var item in objc)
            {
                Console.WriteLine(item);

            }

            foreach (var item in GetNames())
            {
                Console.WriteLine(item);

            }

            foreach (var item in GetNames(true))
            {
                Console.WriteLine(item);

            }
        }


        static IEnumerable GetNames(bool all=false)
        {
            yield return "Ganesh";
            yield return "Mahesh";
            yield return "Dinesh";

            if (!all)
                yield break;
            yield return "Ramesh";


        }


    }


    class Countries : IEnumerable
    {
        string[] _countries = {"India","Japan","USA" };

        public IEnumerator GetEnumerator()
        {
            return new StringEnumerator(_countries);

        }
    }


    class StringEnumerator : IEnumerator
    {
        string[] _data = null;

        int idx = -1;


        public StringEnumerator(string[] data)
        {
            _data = data;

        }
        public object Current
        {
            get
            {
               return _data[idx];
            }
        }

        public bool MoveNext()
        {
            idx++;
            if (idx< _data.Length)
            {
                return true;

            }
            return false;


        }

        public void Reset()
        {
            idx = -1;

        }
    }

}
