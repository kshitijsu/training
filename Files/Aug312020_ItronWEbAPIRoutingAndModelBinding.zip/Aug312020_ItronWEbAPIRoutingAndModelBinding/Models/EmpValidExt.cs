﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace Aug312020_ItronWEbAPIRoutingAndModelBinding.Models
{
    [MetadataType(typeof(EmpValidExt))]
    public partial class Employee
    {
       
    }


        public class EmpValidExt
    {
        [Required]
        public string EmpName;
        [Range(10000,1000000)]
        public Nullable<decimal> Salary;
    }
}