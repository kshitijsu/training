﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Aug272020_Itron_AdoNet
{
    class Program
    {
        static void Main(string[] args)
        {

            SqlConnectionStringBuilder _cnb = new SqlConnectionStringBuilder();

            _cnb.DataSource = @"(localdb)\projectsv13";
            _cnb.IntegratedSecurity = true;
            _cnb.InitialCatalog = "EmployeeDb";

            string _ConString = _cnb.ToString();


            SqlConnection _cn = new SqlConnection(_ConString);


            int Option = 0;
            do
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("1.Display Employee Details\n2.Add New Employee\n3.Edit Employee\n4.Delete Employee\n10.Exit");
                Console.ForegroundColor = ConsoleColor.Blue;
                Console.Write("Enter option:");
                Option = int.Parse( Console.ReadLine());

                if (Option==1)
                {
                    DisplayEmployeeDetails(_cn);
                }

                if (Option == 2)
                {
                    AddNewEmployee(_cn);
                }


                if (Option == 3)
                {
                    AddNewEmployee(_cn);
                }

            } while (Option!=10);

           
           

        }

        private static void AddNewEmployee(SqlConnection _cn)
        {
            string _EmpName = "";
            double  _Salary = 0;
            string _Address = "";


            Console.Clear();

            Console.Write("Enter Emp Name: ");
            _EmpName = Console.ReadLine();

            Console.Write("Address: ");
            _Address = Console.ReadLine();
            Console.Write("Salary: ");
            _Salary =  double.Parse( Console.ReadLine());

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = _cn;
            cmd.CommandText = "INSERT INTO [dbo].[Employee] ( [EmpName], [Address], [Salary]) VALUES ( @enm, @add, @sal)";

            cmd.Parameters.Add("@enm", SqlDbType.VarChar, 50).Value = _EmpName;
            cmd.Parameters.Add("@add", SqlDbType.VarChar, 150).Value = _Address;
            cmd.Parameters.Add("@sal", SqlDbType.Money).Value = _Salary;

           


            _cn.Open();

            if (cmd.ExecuteNonQuery()>0)
            {
                Console.WriteLine("Inserted Successfully!!!!");
                
            }
            else
                Console.WriteLine("Sometime went worng...");

            _cn.Close();

            Console.WriteLine("Press Any key for Menu....");
            Console.ReadKey();

        }

        private static void DisplayEmployeeDetails(SqlConnection _cn)
        {
            Console.Clear();

            SqlCommand cmd = new SqlCommand();
            cmd.Connection = _cn;
            cmd.CommandText = "Select * from employee";
            cmd.CommandType = CommandType.Text;


            _cn.Open();
            SqlDataReader _dr= cmd.ExecuteReader();
            if (_dr.HasRows)
            {
                while (_dr.Read())
                {
                    Console.WriteLine($"EmpName : {_dr.GetValue(1)} . Address :{_dr.GetValue(2)}, Salary :{_dr.GetValue(3)}   ");

                }
            }
            _dr.Close();
            _cn.Close();

            Console.WriteLine("Press Any key for Menu....");
            Console.ReadKey();


        }
    }
}
