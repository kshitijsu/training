import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {  ProductUIComponent } from "./product-ui/product-ui.component";
import { FormsModule,ReactiveFormsModule  } from "@angular/forms";
import { HttpClient,HttpClientModule  } from "@angular/common/http";
import { AppRoutingModule  } from "./app-routing-module";
import { FundTransferInternalComponent } from './fund-transfer-internal/fund-transfer-internal.component';
import { CheckBalanceComponent } from './check-balance/check-balance.component';
import { MiniStatementComponent } from './mini-statement/mini-statement.component';
import { CustomStatementComponent } from './custom-statement/custom-statement.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { DashBoardComponent } from './dash-board/dash-board.component';
import { CatchAllComponent } from './catch-all/catch-all.component';
@NgModule({
  declarations: [
    AppComponent,ProductUIComponent, FundTransferInternalComponent, CheckBalanceComponent, MiniStatementComponent, CustomStatementComponent, ChangePasswordComponent, DashBoardComponent, CatchAllComponent
  ],
  imports: [
    BrowserModule,HttpClientModule,FormsModule,ReactiveFormsModule ,AppRoutingModule
  ],
  providers: [HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
