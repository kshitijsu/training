import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-statement',
  templateUrl: './custom-statement.component.html',
  styleUrls: ['./custom-statement.component.css']
})
export class CustomStatementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
