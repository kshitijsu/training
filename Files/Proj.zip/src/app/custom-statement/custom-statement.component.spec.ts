import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomStatementComponent } from './custom-statement.component';

describe('CustomStatementComponent', () => {
  let component: CustomStatementComponent;
  let fixture: ComponentFixture<CustomStatementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomStatementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomStatementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
