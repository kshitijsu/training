import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import {  BankingCoreService } from "../banking-core.service";
@Component({
  selector: 'app-fund-transfer-internal',
  templateUrl: './fund-transfer-internal.component.html',
  styleUrls: ['./fund-transfer-internal.component.css']
})
export class FundTransferInternalComponent implements OnInit {

  dataSaved = false;  
  FundTransferForm: any;  
 
  message = null;  
  



  constructor(private formbulider: FormBuilder, private BankCoreSvcContext:BankingCoreService) { }  
  
 

  ngOnInit() {  
    this.FundTransferForm = this.formbulider.group({  
      FromAccount: ['200010', [Validators.required]],  
      ToAccount: ['100010', [Validators.required]],  
      Remark: ['some rem', [Validators.required]],  
      Amount: ['10', [Validators.required]],  
    });  
   
        }  


        onFormSubmit(FundData) {  
          this.dataSaved = false;  
          console.log(this.FundTransferForm)
                 
          this.BankCoreSvcContext.FunDTransferIn( FundData.FromAccount, FundData.ToAccount,FundData.Remark,FundData.Amount).subscribe(  
            (data) => {  

              console.log(data)


              if (data==0)
              {
             
              this.dataSaved = true;  
              this.message = 'Transfered  Successfully';  
              }
              if (data==-1)
              {
                this.dataSaved = true;  
                this.message = 'Invalid From Account   ';  

              }

              this.FundTransferForm.reset();  
            }  
          );  

         
         
        }  


        
        }   




