import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BankingCoreService {
  url = 'http://localhost:59293/api/ItronBankCore';  


  constructor(private http: HttpClient) { }  

  FunDTransferIn(fromacc:string, toAcc:string , remark:string,amount:number): Observable<number> {  
    
    return this.http.post<number>(this.url + '?FromAccountNo='+ fromacc+'&remark='+remark +'&Amount='+amount+'&ToAccountNo='+toAcc,"");  
  }  


}
