import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {  ChangePasswordComponent  } from "./change-password/change-password.component";
import {  CheckBalanceComponent  } from "./check-balance/check-balance.component";
import {  CustomStatementComponent  } from "./custom-statement/custom-statement.component";
import {  FundTransferInternalComponent  } from "./fund-transfer-internal/fund-transfer-internal.component";
import {  MiniStatementComponent  } from "./mini-statement/mini-statement.component";
import { DashBoardComponent } from "./dash-board/dash-board.component";
import { CatchAllComponent } from "./catch-all/catch-all.component";
 




const routes: Routes = [
  { path: 'home', component: DashBoardComponent },
  { path: 'fundtransferinternal', component: FundTransferInternalComponent },
  { path: 'balanceenquiry', component: CheckBalanceComponent },
  { path: 'CustomStatement', component: CustomStatementComponent },
  { path: 'ChangePassword', component: ChangePasswordComponent },
  { path: 'MiniStatement', component: MiniStatementComponent },

  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: '**', component: CatchAllComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
