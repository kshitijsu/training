import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mini-statement',
  templateUrl: './mini-statement.component.html',
  styleUrls: ['./mini-statement.component.css']
})
export class MiniStatementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
