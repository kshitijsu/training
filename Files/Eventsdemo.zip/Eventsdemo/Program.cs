﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Eventsdemo
{
    delegate void dlgdemo(int a);

    class Program
    {
        static void Main(string[] args)
        {
            Publisher objPub = new Publisher();
            objPub.somevalue = "test value";
            objPub.Notify += handler;
            objPub.Notify += handler2;
            //objPub.Notify(1000);
            objPub.DoSomething();


        }

        static void handler(int a)
        {
            Console.WriteLine("Handler Called.." + a);
        }
        static void handler2(int a)
        {
            Console.WriteLine("Handler2 Called.." + a);
        }
    }


    class Publisher
    {
        public event dlgdemo Notify;
        public string somevalue = "";
        public void DoSomething()
        {
            if (this.Notify!=null)
            {
                Notify(100);
            }
        }
    }
}
