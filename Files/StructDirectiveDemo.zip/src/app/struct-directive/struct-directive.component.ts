import { Component, OnInit } from '@angular/core';
import { EmpDataProviderService } from '../data-provider.service';

@Component({
  selector: 'app-struct-directive',
  templateUrl: './struct-directive.component.html',
  styleUrls: ['./struct-directive.component.css']
})
export class StructDirectiveComponent implements OnInit {

   constructor(objEmps:EmpDataProviderService)
  {
        this.Employees= objEmps.getEmployeeDetails();
  }
  
  ngifFlg=false;
  Employees=[];

  ngOnInit() {
  }

}
