import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-num-up-down',
  templateUrl: './num-up-down.component.html',
  styleUrls: ['./num-up-down.component.css']
})
export class NumUpDownComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  @Input()  size: number =1;
  @Output() sizeChanged = new EventEmitter<number>();
  
  dec() {this.resize(-1);}
  inc() {this.resize(+1);}


  resize(delta: number) 
    {
      this.size = Math.min(40, Math.max(8, +this.size + delta));
      this.sizeChanged.emit(this.size);
    }
  


}
