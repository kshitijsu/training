﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        public static void Main()
        {


            IEmployee obje = new Employee();
            obje.EmpName = "Ganesha";
            obje.Display();


            Employee obje1 = new Employee();
            obje1.EmpName = "Mahesh";
            obje1.Display();



            //Employee obj = new Employee() { EmpId = 1235, EmpName = "Mahesh", Address = "blr" };


            //var obj1= new Employee { EmpId=1234, EmpName="Ganesh", Address="blr" };

            //var obj2 = new  { EmpId = 1234, EmpName = "Ganesh", Address = "blr" };
            //var obj3 = new { EmpId = 1235, EmpName = "abc", Address = "blr" };
            //var obj4 = new { EmpId = 1235, Address = "blr", EmpName = "abc" };

            //Console.WriteLine(obj1.GetType());
            //Console.WriteLine(obj2.GetType());
            //Console.WriteLine(obj3.GetType());
            //Console.WriteLine(obj4.GetType());


        }

    }


    class Employee:IEmployee
    {

        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public string Address { get; set; }

        public void Display() // imp
        {
            Console.WriteLine(this.EmpName);
        }

         void IEmployee.Display() // exp
        {
            Console.WriteLine(this.EmpName + "Exp");
        }

    }


    interface IEmployee
    {
         int EmpId { get; set; }
         string EmpName { get; set; }
         string Address { get; set; }

        void Display();

    }
}
