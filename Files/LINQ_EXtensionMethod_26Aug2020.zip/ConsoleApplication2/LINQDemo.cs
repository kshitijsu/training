﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class LINQDemo
    {
        static void Main()
        {
            LINQSyntax.BasicIntro();
        }
    }


    class LINQSyntax
    {

        static List<Employee> lst = new List<Employee> { new Employee { EmpId=100, EmpName="Ganesh", Address="Blr" },
            new Employee { EmpId=101, EmpName="ramesh", Address="Blr" },
            new Employee { EmpId=102, EmpName="suresh", Address="pun" },
            new Employee { EmpId=103, EmpName="nagesh", Address="mum" },
            new Employee { EmpId=104, EmpName="rajesh", Address="dhl" },


        };
        public static void BasicIntro()
        {
            // Method call Expression
            IEnumerable<Employee> qry = lst.Where(e => e.Address == "Blr");

            foreach (var item in qry)
            {
                Console.WriteLine(item.EmpName + "from " + item.Address);
            }

            var rst = lst.Where(emp => emp.EmpId > 100).ToList();



        }


    }

}
