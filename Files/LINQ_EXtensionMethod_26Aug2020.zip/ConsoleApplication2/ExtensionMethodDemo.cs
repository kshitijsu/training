﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class ExtensionMethodDemo
    {

        static void Main()
        {
            char c = 'a';

            // in trad way
            ExtensionMethodClass.IsValidEmpIDChar(c);

            c.IsValidEmpIDChar();

            string st = "";
            st.IsValidEmpIDChar();
            Employee obj = new ConsoleApplication2.Employee();

            obj.IsValidEmpIDChar();

            
        }

    }


  static   class ExtensionMethodClass

    {
        public static bool IsValidEmpIDChar(this object c)
        {
            return true;

        }



    }
}
