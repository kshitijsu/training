import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from '../Models/Product';
import { FormBuilder, Validators } from '@angular/forms';
import { ProductDataContextService } from '../Services/product-data-context.service';

@Component({
  selector: 'app-product-ui',
  templateUrl: './product-ui.component.html',
  styleUrls: ['./product-ui.component.css']
})
export class ProductUIComponent implements OnInit {

  dataSaved = false;  
  ProductForm: any;  
  allProducts: Observable<Product[]>;  
  ProductIdUpdate = null;  
  message = null;  
  
  constructor(private formbulider: FormBuilder, private ProductService:ProductDataContextService) { }  
  
 

  ngOnInit() {  
    this.ProductForm = this.formbulider.group({  
      ProductName: ['', [Validators.required]],  
      Category: ['', [Validators.required]],  
      
    });  
    this.loadAllProducts();  
  }  

  loadAllProducts() {  
    this.allProducts = this.ProductService.getAllProduct();  
  }  


  onFormSubmit() {  
    this.dataSaved = false;  
    const Product = this.ProductForm.value;  
    this.CreateOrUpdateProduct(Product);  
    this.ProductForm.reset();  
  }  
  loadProductToEdit(ProductId: string) {  
    this.ProductService.getProductById(ProductId).subscribe(Product=> {  
      this.message = null;  
      this.dataSaved = false;  
      this.ProductIdUpdate = Product.ProductId;  
      this.ProductForm.controls['ProductName'].setValue(Product.ProductName);  
     this.ProductForm.controls['Category'].setValue(Product.Category); 
    });  
  
  }  
  CreateOrUpdateProduct(Product: Product) {  
    if (this.ProductIdUpdate == null) {  
      this.ProductService.createProduct(Product).subscribe(  
        () => {  
          this.dataSaved = true;  
          this.message = 'Record saved Successfully';  
          this.loadAllProducts();  
          this.ProductIdUpdate = null;  
          this.ProductForm.reset();  
        }  
      );  
    } else {  
      Product.ProductId = this.ProductIdUpdate;  
      this.ProductService.updateProduct(Product).subscribe(() => {  
        this.dataSaved = true;  
        this.message = 'Record Updated Successfully';  
        this.loadAllProducts();  
        this.ProductIdUpdate = null;  
        this.ProductForm.reset();  
      });  
    }  
  }   
  deleteProduct(ProductId: string) {  
    if (confirm("Are you sure you want to delete this ?")) {   
    this.ProductService.deleteProductById(ProductId).subscribe(() => {  
      this.dataSaved = true;  
      this.message = 'Record Deleted Succefully';  
      this.loadAllProducts();  
      this.ProductIdUpdate = null;  
      this.ProductForm.reset();  
  
    });  
  }  
}  
  resetForm() {  
    this.ProductForm.reset();  
    this.message = null;  
    this.dataSaved = false;  
  }  
}  