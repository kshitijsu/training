import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ProductUIComponent } from './product-ui/product-ui.component';

import { FormsModule,ReactiveFormsModule  } from "@angular/forms";
import { HttpClient,HttpClientModule  } from "@angular/common/http";

@NgModule({
  declarations: [
    AppComponent,
    ProductUIComponent
  ],
  imports: [
    BrowserModule,HttpClientModule,
    AppRoutingModule,FormsModule,ReactiveFormsModule
  ],
  providers: [HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
