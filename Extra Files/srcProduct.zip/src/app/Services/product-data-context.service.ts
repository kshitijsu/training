import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from '../Models/Product';

@Injectable({
  providedIn: 'root'
})
export class ProductDataContextService {

  url = 'http://localhost:52958/api';  


  constructor(private http: HttpClient) { }  



  getAllProduct(): Observable<Product[]> {  
    return this.http.get<Product[]>(this.url + '/product');  
  }  


  getProductById(ProductId: string): Observable<Product> {  
    return this.http.get<Product>(this.url + '/product/' + ProductId);  
  }  


  createProduct(Product: Product): Observable<Product> {  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };  
    return this.http.post<Product>(this.url + '/product/',  
    Product, httpOptions);  
  }  


  updateProduct(Product: Product): Observable<Product> {  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };  
    return this.http.put<Product>(this.url + '/product/' + Product.ProductId,  
    Product, httpOptions);  
  }  

  
  deleteProductById(Productid: string): Observable<number> {  
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json'}) };  
    return this.http.delete<number>(this.url + '/product/?id=' +Productid,  
 httpOptions);  
  }  

}