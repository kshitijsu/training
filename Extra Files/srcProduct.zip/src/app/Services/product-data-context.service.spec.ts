import { TestBed } from '@angular/core/testing';

import { ProductDataContextService } from './product-data-context.service';

describe('ProductDataContextService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProductDataContextService = TestBed.get(ProductDataContextService);
    expect(service).toBeTruthy();
  });
});
