export class Product
 {
    ProductId:number
 ProductName:string 
    Category:string 
}