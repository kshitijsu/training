import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Account } from '../Models/Account';

@Injectable({
  providedIn: 'root'
})
export class BalanceDataContextService {

  url = 'http://localhost:61564/api';

  constructor(private http: HttpClient) { }

  getBalance(AccountNumber: string): Observable<number> {  
    return this.http.get<number>(this.url + '/ItronBankCore/?AccountNumber=' + AccountNumber);  
  } 
  
}
