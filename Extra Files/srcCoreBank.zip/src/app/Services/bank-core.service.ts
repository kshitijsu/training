import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Mini} from "../Models/Account";

@Injectable({
  providedIn: 'root'
})
export class BankCoreService {

  url = 'http://localhost:61564/api/ItronBankCore';

  constructor(private http: HttpClient) { }

  FunDTransferIn(FromAcc: string, ToAcc: string, amount:number ): Observable<number> {  
    return this.http.post<number>(this.url + '?FromAccNo='+FromAcc+'&ToAccNo='+ToAcc+'&amount='+amount,"");  
  } 

  //updated int uid, string oldPW, string newPW, string confpass
  ChangePassword(UserId: number, oldpass: string, newpass: string,confpass: string): Observable<number> {
    return this.http.post<number>(this.url + '?uid='+UserId+'&oldPW='+oldpass+'&newPW='+newpass+'&confpass='+confpass,"");
  }

  GetBalance(AccNo: number): Observable<number> {
    return this.http.get<number>(this.url + '?AccountNumber='+ AccNo);
  }

  GetMiniStatement(AccNo: string, notrans: number) : Observable<Mini[]> {
    return this.http.get<Mini[]>(this.url + '?AccountNumber='+AccNo+'&notrans='+notrans);
  }

  GetCustomStatement(AccNo: string, FromDate:Date, ToDate:Date): Observable<Mini[]> {
    return this.http.get<Mini[]>(this.url + '?AccountNumber='+AccNo+'&from='+FromDate+'&to='+ToDate);
  }

}
