export class Account
{
    AccountNumber:string           
    CurrentAmount:number 
}

export class Mini{

    TransactionID: number
    AccountId: number
    TransType: string
    TransDateTime: Date
    TransDesc: string
    Debit: number
    Credit: number
    
}