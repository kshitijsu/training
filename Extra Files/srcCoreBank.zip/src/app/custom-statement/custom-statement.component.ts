import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { BankCoreService } from '../Services/bank-core.service';
import { Mini } from "../Models/Account";
import { observable, Observable } from 'rxjs';

@Component({
  selector: 'app-custom-statement',
  templateUrl: './custom-statement.component.html',
  styleUrls: ['./custom-statement.component.css']
})
export class CustomStatementComponent implements OnInit {

  dataSaved = false;  
  CustStmtForm: any;     
  allTransactions : Observable<Mini[]>;

  constructor(private formbulider: FormBuilder, private BankCoreSvcContext:BankCoreService) { }

  ngOnInit() {

    this.CustStmtForm = this.formbulider.group({
      AccNo: ['', [Validators.required]],  
      FromDate: ['', [Validators.required]],
      ToDate: ['', [Validators.required]]
    });
  }

  onFormSubmit(CustStmtData) { 

    this.dataSaved = false;  
    console.log(this.CustStmtForm);
           
    //this.BankCoreSvcContext.FunDTransferIn(FundData.FromAccNo, FundData.TOAccNo,FundData.amount).subscribe(  
     this.allTransactions = this.BankCoreSvcContext.GetCustomStatement( CustStmtData.AccNo, CustStmtData.FromDate, CustStmtData.ToDate);
       
  }


}
