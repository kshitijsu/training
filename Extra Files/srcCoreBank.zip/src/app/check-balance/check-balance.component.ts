import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { BankCoreService } from '../Services/bank-core.service';
import { strictEqual } from 'assert';


@Component({
  selector: 'app-check-balance',
  templateUrl: './check-balance.component.html',
  styleUrls: ['./check-balance.component.css']
})
export class CheckBalanceComponent implements OnInit {

  dataSaved = false;  
  CheckBalanceForm: any;     
  message = null;
  

  constructor(private formbulider: FormBuilder, private BankCoreSvcContext:BankCoreService) { }

  ngOnInit() {
    
    this.CheckBalanceForm = this.formbulider.group({
      accno: ['',[Validators.required]]
    });
    
  }

  onFormSubmit(balanceData) {

    this.dataSaved = false;
    console.log(this.CheckBalanceForm);

    this.BankCoreSvcContext.GetBalance(balanceData.accno).subscribe(  
      (data) => {  

        console.log(data);
        
        if (data>0)
        {
       
        this.dataSaved = true;  
        // this.message = 'Balance Retrieved Successfully:' + '<\br>';
        // this.message += "Balance:" + data;  
        this.message = "Balance: " + data;
        }
        else
        {
          this.dataSaved = true;  
          this.message = 'Invalid Account Number';  

        }

        this.CheckBalanceForm.reset();  
      }  
    );  

  }
  

} 

