import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { CheckBalanceComponent } from './check-balance/check-balance.component';
import { CustomStatementComponent } from './custom-statement/custom-statement.component';
import { DashBoardComponent } from './dash-board/dash-board.component';
import { FundTransferInternalComponent } from './fund-transfer-internal/fund-transfer-internal.component';
import { MiniStatementComponent } from './mini-statement/mini-statement.component';
import { CatchAllComponent } from './catch-all/catch-all.component';

import { FormsModule,ReactiveFormsModule  } from "@angular/forms";
import { HttpClient,HttpClientModule  } from "@angular/common/http";

@NgModule({
  declarations: [
    AppComponent,
    ChangePasswordComponent,
    CheckBalanceComponent,
    CustomStatementComponent,
    DashBoardComponent,
    FundTransferInternalComponent,
    MiniStatementComponent,
    CatchAllComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,FormsModule,ReactiveFormsModule 
  ],
  providers: [HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
