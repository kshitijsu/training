import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-catch-all',
  templateUrl: './catch-all.component.html',
  styleUrls: ['./catch-all.component.css']
})
export class CatchAllComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
