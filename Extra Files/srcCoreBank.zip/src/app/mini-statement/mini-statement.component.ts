import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { BankCoreService } from '../Services/bank-core.service';
import { Mini } from "../Models/Account";
import { observable, Observable } from 'rxjs';


@Component({
  selector: 'app-mini-statement',
  templateUrl: './mini-statement.component.html',
  styleUrls: ['./mini-statement.component.css']
})
export class MiniStatementComponent implements OnInit {

  dataSaved = false;  
  MiniStmtForm: any;     
  allTransactions : Observable<Mini[]>;

  constructor(private formbulider: FormBuilder, private BankCoreSvcContext:BankCoreService) { }

  ngOnInit() {

    this.MiniStmtForm = this.formbulider.group({
      // updated int uid, string oldPW, string newPW, string confpass
      AccNo: ['', [Validators.required]],  
      NoOfTrans: ['', [Validators.required]]
    });
  }

  onFormSubmit(MiniStmtData) { 

    this.dataSaved = false;  
    console.log(this.MiniStmtForm);
           
    //this.BankCoreSvcContext.FunDTransferIn(FundData.FromAccNo, FundData.TOAccNo,FundData.amount).subscribe(  
     this.allTransactions = this.BankCoreSvcContext.GetMiniStatement( MiniStmtData.AccNo, MiniStmtData.NoOfTrans);
       
  }

}
