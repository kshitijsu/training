import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { BankCoreService } from '../Services/bank-core.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  dataSaved = false;  
  PasswordForm: any;     
  message = null;

  constructor(private formbulider: FormBuilder, private BankCoreSvcContext:BankCoreService) { }

  ngOnInit() {

    this.PasswordForm = this.formbulider.group({
      // updated int uid, string oldPW, string newPW, string confpass
      UserId: ['', [Validators.required]],  
      oldpass: ['', [Validators.required]],
      newpass: ['',[Validators.required]],
      confpass: ['',[Validators.required]]
    });
  }

  onFormSubmit(PasswordData) { 

    this.dataSaved = false;  
    console.log(this.PasswordForm);
           
    //this.BankCoreSvcContext.FunDTransferIn(FundData.FromAccNo, FundData.TOAccNo,FundData.amount).subscribe(  
      this.BankCoreSvcContext.ChangePassword( PasswordData.UserId, PasswordData.oldpass, PasswordData.newpass, PasswordData.confpass).subscribe(  
      (data) => {  

        console.log(data);
        
        if (data==0)
        {
       
        this.dataSaved = true;  
        this.message = 'Password Changed Successfully';  
        }
        if (data==-1)
        {
          this.dataSaved = true;  
          this.message = 'Invalid Password';  

        }

        this.PasswordForm.reset();  
      }  
    );  

  }

}
