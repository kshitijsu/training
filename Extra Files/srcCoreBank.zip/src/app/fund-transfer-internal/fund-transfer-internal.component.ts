import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { BankCoreService } from '../Services/bank-core.service';

@Component({
  selector: 'app-fund-transfer-internal',
  templateUrl: './fund-transfer-internal.component.html',
  styleUrls: ['./fund-transfer-internal.component.css']
})
export class FundTransferInternalComponent implements OnInit {

  dataSaved = false;  
  FundTransferForm: any;     
  message = null;
  

  constructor(private formbulider: FormBuilder, private BankCoreSvcContext:BankCoreService) { }

  ngOnInit() {

    this.FundTransferForm = this.formbulider.group({

      FromAccNo: ['10009', [Validators.required]],  
      ToAccNo: ['10001', [Validators.required]],
      amount: ['10',[Validators.required]]
    });
  }

  onFormSubmit(FundData) { 

    this.dataSaved = false;  
    console.log(this.FundTransferForm);
           
    //this.BankCoreSvcContext.FunDTransferIn(FundData.FromAccNo, FundData.TOAccNo,FundData.amount).subscribe(  
      this.BankCoreSvcContext.FunDTransferIn( FundData.FromAccNo, FundData.ToAccNo,FundData.amount).subscribe(  
      (data) => {  

        console.log(data);
        
        if (data==0)
        {
       
        this.dataSaved = true;  
        this.message = 'Transfered  Successfully';  
        }
        if (data==-1)
        {
          this.dataSaved = true;  
          this.message = 'Invalid From Account   ';  

        }

        this.FundTransferForm.reset();  
      }  
    );  


  }
}
