import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FundTransferInternalComponent } from './fund-transfer-internal.component';

describe('FundTransferInternalComponent', () => {
  let component: FundTransferInternalComponent;
  let fixture: ComponentFixture<FundTransferInternalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FundTransferInternalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FundTransferInternalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
